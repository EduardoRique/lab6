Repositório para o laboratório 6 da disciplina de linguagem de programação 1

Compilação: Para gerar o binários basta executar o comando "make" no diretório raiz do projeto. Automaticamente serao gerados os arquivos executaveis na pasta bin

Execução: A execução do programa deve ser, por exemplo: ./bin/prog
Para inicializar o programa 3 com um arquivo basta inserir na pasta "data" um arquivo com o nome "entrada.txt"