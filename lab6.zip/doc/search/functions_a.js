var searchData=
[
  ['setnome',['setnome',['../classTurma.html#afdd8323141e06aae061b349da7faed32',1,'Turma']]]
];
