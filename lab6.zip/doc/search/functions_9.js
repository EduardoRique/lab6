var searchData=
[
  ['remove_5fespacos',['remove_espacos',['../tratastring_8h.html#ad9410c3aac66a30ca3358664a18e69c3',1,'remove_espacos(string &amp;s):&#160;tratastring.cpp'],['../tratastring_8cpp.html#ad9410c3aac66a30ca3358664a18e69c3',1,'remove_espacos(string &amp;s):&#160;tratastring.cpp']]],
  ['remove_5fpontuacao',['remove_pontuacao',['../tratastring_8h.html#a2b03312ff168b030cd475c9060ae48eb',1,'remove_pontuacao(string &amp;s):&#160;tratastring.cpp'],['../tratastring_8cpp.html#a2b03312ff168b030cd475c9060ae48eb',1,'remove_pontuacao(string &amp;s):&#160;tratastring.cpp']]],
  ['remover',['Remover',['../classLista.html#a60b5cc2bf48de5e10693297e7400655c',1,'Lista::Remover(T el)'],['../classLista.html#a60b5cc2bf48de5e10693297e7400655c',1,'Lista::Remover(T el)'],['../classTurma.html#adbe30f367dc083a4fff959ac4bb4fd3a',1,'Turma::Remover()'],['../classLista.html#a60b5cc2bf48de5e10693297e7400655c',1,'Lista::Remover()'],['../classTurma.html#adbe30f367dc083a4fff959ac4bb4fd3a',1,'Turma::Remover()']]]
];
