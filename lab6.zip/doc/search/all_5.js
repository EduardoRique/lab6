var searchData=
[
  ['lista',['Lista',['../classLista.html',1,'Lista&lt; T &gt;'],['../classLista.html#adce924e21607848663132290be1a959d',1,'Lista::Lista()'],['../classLista.html#adce924e21607848663132290be1a959d',1,'Lista::Lista()'],['../classLista.html#adce924e21607848663132290be1a959d',1,'Lista::Lista()']]],
  ['lista_3c_20aluno_20_3e',['Lista&lt; Aluno &gt;',['../classLista.html',1,'']]]
];
