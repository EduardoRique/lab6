var searchData=
[
  ['aluno',['Aluno',['../classAluno.html#accae0e6be51e4c5905b2eef72fdba25a',1,'Aluno::Aluno(string n=&quot;&quot;, long int m=0, int f=0, float no=0)'],['../classAluno.html#accae0e6be51e4c5905b2eef72fdba25a',1,'Aluno::Aluno(string n=&quot;&quot;, long int m=0, int f=0, float no=0)']]]
];
