var searchData=
[
  ['getcabeca',['getCabeca',['../classLista.html#aa63a768b1fd0091dbffe52fa1cb1f524',1,'Lista::getCabeca()'],['../classLista.html#aa63a768b1fd0091dbffe52fa1cb1f524',1,'Lista::getCabeca()']]],
  ['getnome',['getnome',['../classTurma.html#a90ddbb958cdabda2db30645fc5fe4067',1,'Turma']]]
];
