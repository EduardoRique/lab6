var searchData=
[
  ['tratar_5fstring',['tratar_string',['../tratastring_8h.html#ab73ebee468f7c226e911c9f6e190799a',1,'tratar_string(string &amp;s):&#160;tratastring.cpp'],['../tratastring_8cpp.html#ab73ebee468f7c226e911c9f6e190799a',1,'tratar_string(string &amp;s):&#160;tratastring.cpp']]],
  ['tratastring_2ecpp',['tratastring.cpp',['../tratastring_8cpp.html',1,'']]],
  ['tratastring_2eh',['tratastring.h',['../tratastring_8h.html',1,'']]],
  ['turma',['Turma',['../classTurma.html',1,'Turma'],['../classTurma.html#a8ad1feec07b4c0ff5d4ec51c8b4a61fd',1,'Turma::Turma()'],['../classTurma.html#a8ad1feec07b4c0ff5d4ec51c8b4a61fd',1,'Turma::Turma()']]]
];
