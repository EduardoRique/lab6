var searchData=
[
  ['quais',['quais',['../classTurma.html#ad8b93ef5d38faaebd61966a18c4127ee',1,'Turma::quais()'],['../classTurma.html#ad8b93ef5d38faaebd61966a18c4127ee',1,'Turma::quais()']]],
  ['quantos',['quantos',['../classTurma.html#a77e53245b6dc059082361f57f8519c93',1,'Turma::quantos()'],['../classTurma.html#a77e53245b6dc059082361f57f8519c93',1,'Turma::quantos()']]]
];
