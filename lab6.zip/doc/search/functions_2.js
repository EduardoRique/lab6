var searchData=
[
  ['inserir',['Inserir',['../classLista.html#a3f86da92f17f6d93365a4a9b0f88a26a',1,'Lista::Inserir(T el)'],['../classLista.html#a3f86da92f17f6d93365a4a9b0f88a26a',1,'Lista::Inserir(T el)'],['../classTurma.html#afd65afe1581a4d12a325d7e89112d2e9',1,'Turma::Inserir()'],['../classLista.html#a3f86da92f17f6d93365a4a9b0f88a26a',1,'Lista::Inserir()'],['../classTurma.html#afd65afe1581a4d12a325d7e89112d2e9',1,'Turma::Inserir()']]]
];
