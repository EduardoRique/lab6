var searchData=
[
  ['dado',['dado',['../classNode.html#a6fbc3cbab60915be502828d2e3ffa845',1,'Node']]]
];
