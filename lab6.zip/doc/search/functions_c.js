var searchData=
[
  ['_7elista',['~Lista',['../classLista.html#af297975e278b0c92cbf67d14b2f08366',1,'Lista::~Lista()'],['../classLista.html#af297975e278b0c92cbf67d14b2f08366',1,'Lista::~Lista()'],['../classLista.html#af297975e278b0c92cbf67d14b2f08366',1,'Lista::~Lista()']]]
];
