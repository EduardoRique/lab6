var searchData=
[
  ['tratastring_2ecpp',['tratastring.cpp',['../tratastring_8cpp.html',1,'']]],
  ['tratastring_2eh',['tratastring.h',['../tratastring_8h.html',1,'']]]
];
