var searchData=
[
  ['faltas',['faltas',['../classAluno.html#a36afc8fd74be5bc44a78396453bb9b48',1,'Aluno']]]
];
