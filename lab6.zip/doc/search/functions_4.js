var searchData=
[
  ['media',['media',['../classTurma.html#afc7e4355a7d46e73e6aa57bb80212a1b',1,'Turma::media()'],['../classTurma.html#afc7e4355a7d46e73e6aa57bb80212a1b',1,'Turma::media()']]],
  ['minusculas',['minusculas',['../tratastring_8h.html#ae43cf6b49fec4f2227f8a73cca5b2080',1,'minusculas(string &amp;s):&#160;tratastring.cpp'],['../tratastring_8cpp.html#ae43cf6b49fec4f2227f8a73cca5b2080',1,'minusculas(string &amp;s):&#160;tratastring.cpp']]]
];
