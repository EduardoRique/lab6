var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../classTurma.html#a3ee8071434f00659571eabae9aac2eff',1,'Turma::operator&lt;&lt;()'],['../classTurma.html#a3ee8071434f00659571eabae9aac2eff',1,'Turma::operator&lt;&lt;()']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../classTurma.html#a0d37e577a566b3a110ef286a2e797e94',1,'Turma::operator&gt;&gt;()'],['../classTurma.html#a0d37e577a566b3a110ef286a2e797e94',1,'Turma::operator&gt;&gt;()']]]
];
