var searchData=
[
  ['matricula',['matricula',['../classAluno.html#a75862be7fc3cd5c09bcd8e30e92247aa',1,'Aluno']]]
];
