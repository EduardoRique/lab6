var searchData=
[
  ['lista',['Lista',['../classLista.html#adce924e21607848663132290be1a959d',1,'Lista::Lista()'],['../classLista.html#adce924e21607848663132290be1a959d',1,'Lista::Lista()'],['../classLista.html#adce924e21607848663132290be1a959d',1,'Lista::Lista()']]]
];
