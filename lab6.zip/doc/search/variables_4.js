var searchData=
[
  ['nome',['nome',['../classAluno.html#a22e26cb85066e4dfdc144c502819a7b4',1,'Aluno']]],
  ['nota',['nota',['../classAluno.html#ae664a02b5e6cffaffe2b47479481873e',1,'Aluno']]]
];
